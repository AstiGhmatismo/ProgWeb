<?php
// Exercício 1 – Exibir os números de 1 a 10 (loop for)

for ($i = 1; $i <= 10; $i++) {
    echo $i . "<br>";
}
