<?php
// Exercício 3 – Escada com 5 degraus, subindo um degrau por vez (loop for)

for ($degrau = 1; $degrau <= 5; $degrau++) {
    echo "Você está no degrau " . $degrau . "<br>";
}
