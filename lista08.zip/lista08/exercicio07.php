<?php
// Exercício 7 – Festa para alienígenas: entrada dos 15 primeiros, com o alienígena especial (nº 7) (loop for)

for ($alienigena = 1; $alienigena <= 15; $alienigena++) {
    echo "Alienígena número " . $alienigena . " entrou na festa.";

    if ($alienigena == 7) {
        echo " O alienígena especial chegou!";
    }

    echo "<br>";
}
