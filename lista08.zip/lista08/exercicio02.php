<?php
// Exercício 2 – Contagem regressiva para o lançamento de um foguete, iniciando em 10 (loop for)

for ($i = 10; $i >= 1; $i--) {
    echo $i . "<br>";
}
echo "Lançar! 🚀<br>";
