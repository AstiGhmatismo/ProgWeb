<?php
// Exercício 5 – Caça ao Tesouro: coordenadas de 1 a 20, tesouro na coordenada 15 (loop for)

for ($coordenada = 1; $coordenada <= 20; $coordenada++) {
    echo "Coordenada " . $coordenada;

    if ($coordenada == 15) {
        echo " - Tesouro encontrado!";
    }

    echo "<br>";
}
