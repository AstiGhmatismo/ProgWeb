<?php
// Exercício 4 – Bateria do robô: começa em 0% e aumenta 10% por vez até 100% (loop for)

for ($bateria = 0; $bateria <= 100; $bateria += 10) {
    echo "Bateria do robô: " . $bateria . "%<br>";
}
