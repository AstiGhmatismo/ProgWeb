<?php
// Exercício 1 - Menu de refeições
$opcao = 2; // altere para 1, 2 ou 3

switch ($opcao) {
    case 1:
        echo "Hambúrguer";
        break;
    case 2:
        echo "Pizza";
        break;
    case 3:
        echo "Sushi";
        break;
    default:
        echo "Opção inválida.";
}
